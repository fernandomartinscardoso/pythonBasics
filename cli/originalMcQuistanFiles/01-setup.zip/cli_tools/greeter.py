# greeter.py

def greet():
    print("Hello")
