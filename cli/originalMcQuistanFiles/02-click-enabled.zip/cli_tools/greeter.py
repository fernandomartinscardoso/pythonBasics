# greeter.py

import click

@click.command()
def greet():
    """Displays a greeting to the user."""
    click.echo("Hello")
